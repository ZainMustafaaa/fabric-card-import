import React from 'react';
import './App.css';
import Card from './worker';

function App() {
  return (
    <div className="App"style={{
      height: '100%'
    }}>
      <Card></Card>
    </div>
  );
}

export default App;
